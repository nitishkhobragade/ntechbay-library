import { courseData } from './courseData.js';

console.log(courseData.btech.semesters);  // will work if path correct and module supported